require 'PRY'

# 2 joueurs ;
# Que chaque joueur ait un niveau de vie donné ;
# Que ce niveau de vie baisse à chaque attaque subie ;
# Si la vie atteint zéro, le personnage est mort.


# 2.2. Version 1.0 : coder un combat entre 2 joueurs

class Player
    attr_accessor :name, :life_points, :level, :weapon_level

    # A) Initialiser un joueur avec son nom et sa vie.
    def initialize(name, life_points, level)
        @name = name
        @life_points = life_points
        @level = level
        @weapon_level = weapon_level
    end

    # B) Méthode qui donne la vie du joueur.
    def show_state 
        puts "Le personnage #{@name} a #{@life_points} points de vie, et une arme de niveau #{@weapon_level}."
    end

    # C)1) Méthode qui donne le niveau de vie du joueur.
    def get_damage(damage_received)
        @life_points = @life_points - damage_received
        show_state
    end

    # C)2) Si le niveau de vie de l'objet est inférieur ou égal à zéro, le joueur est tué et on affiche un message.
    def dead?
        if @life_points <= 0
            puts "Le personnage #{@name} est mort."
        end
    end

    # D)1) Player : attaquer avec attacks.
    def attack(player_attacked)
        puts "Le personnage #{@name} attaque #{player_attacked.name}."
        player_attacked.get_damage(@level)
    end

    # D)2) Les dommages seront aléatoires car égaux au résultat d'un lancé de dé (= un chiffre au hasard entre 1 et 6).
    def compute_damage
        return rand(1..6)
    end

    # E) Orchestrons un combat !
    def start_game(player_attacked)
        puts "Le combat commence."
        while player_attacked.life_points > 0 && @life_points > 0
            attack(player_attacked)
            player_attacked.dead?
            player_attacked.show_state
            show_state
        end
    end

end

# 2.3. Version 2.0 : créer un nouveau type de joueur

class HumanPlayer < Player
    def initialize(name, life_points, level, weapon_level)
        super(name, life_points, level, weapon_level)
    end
end

class ComputerPlayer < Player
    def initialize(name, life_points, level, weapon_level)
        super(name, life_points, level, weapon_level)
    end
end

# 1) Créer un joueur humain et un joueur ordinateur.
player_human = HumanPlayer.new("Joueur humain", 10, 1)
player_computer = ComputerPlayer.new("Joueur ordinateur", 10, 1)

# 2) Ordonnons le combat !
player_human.start_game(player_computer)



# b) HumanPlayer : l'attribut @weapon_level et modification de initialize et show_state
# Il y aura 2 choses qui vont différencier un HumanPlayer d'un Player.

# Tout d'abord, on va donner un petit avantage à notre joueur humain vis-à-vis des bots : 
# il disposera de 100 points de vie. 
def HumanPlayer.initialize(name, life_points, level, weapon_level)
    super(name, 100, level)
end

# Deuxièmement, on va ajouter une méthode à notre joueur humain : 
# il pourra utiliser son arme !
def HumanPlayer.use_weapon(player_attacked)
    puts "Le personnage #{@name} utilise son arme."
    player_attacked.get_damage(@weapon_level)
end

# 3) Créer un joueur humain et un joueur ordinateur.
player_human = HumanPlayer.new("Joueur humain", 10, 1)
player_computer = ComputerPlayer.new("Joueur ordinateur", 10, 1)

# 4) Ordonnons le combat !
player_human.start_game(player_computer)

# Elle donne une valeur de 100 à @life_points.
life_points = 100
# Elle fixe @weapon_level = 1.
weapon_level = 1


# d) HumanPlayer : chercher une nouvelle arme
# Une nouvelle fonctionnalité spécifique aux HumanPlayer sera la possibilité pour lui d'aller chercher une nouvelle arme, plus puissante. 
# Pour cela, tu vas coder, dans la classe HumanPlayer, une méthode search_weapon qui va faire les choses suivantes :
class HumanPlayer
    # Elle va commencer par lancer un "dé" dont le résultat sera compris entre 1 et 6.
    
    # Ce lancé de dé sera égal au niveau de la nouvelle arme trouvée. 
    # Annonce le résultat de la recherche à l'utilisateur en affichant un message du genre "Tu as trouvé une arme de niveau XXX".

# Maintenant, cherche à savoir si ça vaut le coup pour le joueur Human Player de la garder… 
# Utilise un if pour comparer le niveau de cette nouvelle arme avec celle qu'il possède déjà (@weapon_level).

# Si l'arme trouvée est d'un niveau strictement supérieur, il la garde. 
# Son @weapon_level prend alors la valeur de la nouvelle arme et tu affiches un message du genre "Youhou ! elle est meilleure que ton arme actuelle : tu la prends."

# Si l'arme trouvée est égale ou moins bien que son arme actuelle, 
# tu ne changes rien et ne fais qu'afficher un petit de déception : 
# "elle n'est pas mieux que ton arme actuelle..."


# e) HumanPlayer : chercher un pack de points de vie
# Une autre fonctionnalité qu'auront les HumanPlayer : 
# ils pourront partir à la recherche d'un pack de points de vie afin de faire remonter leur niveau de vie. 
# De façon assez similaire à la méthode search_weapon, 
# tu vas coder une méthode search_health_pack qui va se comporter comme suit :

# Elle commence également par lancer un "dé" dont le résultat sera compris entre 1 et 6. 
# En fonction du résultat, voilà ce qu'elle devra faire :
# Si le résultat est égal à 1, le joueur n'a rien trouvé et on retourne simplement le string "Tu n'as rien trouvé... ".
# Si le résultat est compris entre 2 (inclus) et 5 (inclus), le joueur a trouvé un pack de 50 points de vie. On va donc augmenter sa vie de 50 points mais sans qu'elle puisse dépasser 100 points. Puis on va retourner le string "Bravo, tu as trouvé un pack de +50 points de vie !".
# Si le résultat est égal à 6, le joueur a trouvé un pack de 80 points de vie. On va donc augmenter sa vie de 80 points mais sans qu'elle puisse dépasser 100 points. Puis on va retourner le string "Waow, tu as trouvé un pack de +80 points de vie !".