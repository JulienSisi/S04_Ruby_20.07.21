require 'bundler'
Bundler.require

require_relative 'lib/game.rb'
require_relative 'lib/player.rb'

binding.pry

# E) Orchestrons un combat !

# À ma droite "Josiane" : crée un Player répondant à ce doux prénom et stocké dans la variable player1.
Player.new("Josiane", 10, 5).start_game

# À ma gauche "José" : crée un autre Player répondant à ce joli prénom et stocké dans la variable player2.
Player.new("José", 10, 4).start_game

# Présentations des deux combattants : 
puts "Voici l'état de chaque joueur :"
show_state(player1)
puts"\n"
show_state(player2)


# Fight ! Indique que le combat commence avec un puts "Passons à la phase d'attaque :".
puts "Passons à la phase d'attaque :"
# Josiane aura l'honneur d'attaquer la première : fais attaquer player2 par player1 avec la méthode attacks.
player1.attack(player2)

# José ne va pas se laisser faire : fais l'attaque inverse.
player2.attack(player1)


# Boucle while qui continue tant que le joueur 1 a plus de point de vie que le joueur 2.
while player1.hp > 0 and player2.hp > 0
  # Et on continue de faire les attaques.
  player1.attack(player2)
  player2.attack(player1)
end

# On affiche le résultat du combat :
puts "Le combat est terminé :"
show_state(player1)
puts"\n"
show_state(player2)

# On affiche le gagnant :
puts "Le gagnant est #{player1.name}"

# Après la fin du combat, on affiche le résultat avec un puts.
puts "Le combat est terminé. Le gagnant est #{player1.name} avec #{player1.hp} points de vie."

