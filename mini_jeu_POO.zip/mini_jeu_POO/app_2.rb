# f) Combat interactif sur app_2.rb : toi contre José et Josiane
# OK, tous les ingrédients sont prêts: il ne nous reste plus qu'à mettre le tout en musique pour enfin jouer ton premier interactif ! 
# Cela va se faire au tour-par-tour et à chaque fois tu auras le choix entre plusieurs actions afin de te défaire de tes 2 adversaires.

# Le fichier qui va orchestrer tout cela va s'appeler app_2.rb afin que tu gardes intacte ta version 1.0 sur app.rb. 
# Commence donc par créer ce fichier (toujours à la racine de ton dossier) et fais-le commencer par les mêmes 4 lignes de code que ton app.rb de base :

# require 'bundler'
# Bundler.require

# require_relative 'lib/game'
# require_relative 'lib/player'
# Maintenant, voici la liste de ce que tu dois coder dans app_2.rb. Fais-le au fur et à mesure, et ne passe à l'étape suivante que si ton code marche :

# Accueil : Commence par afficher dans le terminal, au lancement de app_2.rb, un petit message de démarrage du jeu. Laisse libre cours à ton imagination mais voici un exemple basique :
# ------------------------------------------------
# |Bienvenue sur 'ILS VEULENT TOUS MA POO' !      |
# |Le but du jeu est d'être le dernier survivant !|
# -------------------------------------------------
# Initialisation du joueur: ensuite, le jeu va demander à l'utilisateur son prénom et créer un HumanPlayer portant ce prénom.
# Initialisation des ennemis : le jeu va maintenant créer nos deux combattants préférés, "Josiane" et "José".
# Comme nous savons qu'à terme (version 3.0) il y aura plus de 2 ennemis, on va mettre en place une astuce pour manipuler facilement un groupe d'ennemis : le jeu va créer un array enemies qui va contenir les deux objets Player que sont José et Josiane. Tu verras plus tard l'usage qu'on va en faire.
# Le combat : tout comme dans la version 1.0, on peut maintenant lancer le combat ! Tu vas ouvrir une boucle while qui ne doit s'arrêter que si le joueur de l'utilisateur (HumanPlayer) meurt ou si les 2 joueurs "bots" (Player) meurent. Cette condition d'arrêt n'est pas triviale à écrire mais je te propose d'essayer ! Sinon la réponse est disponible plus bas. Laisse la boucle while vide pour le moment, on la codera juste après.
# Fin du jeu : maintenant, si on sort de cette boucle while, c'est que la partie est terminée. Donc juste en dessous du end de la boucle, on va préparer un petit message de fin. Le jeu doit afficher "La partie est finie" et ensuite soit afficher "BRAVO ! TU AS GAGNE !" si le joueur humain est toujours en vie, ou "Loser ! Tu as perdu !" s'il est mort.
# Très bien, on a l'ossature globale du jeu version 2.0 mais il reste à coder le combat ! Voici ce que tu vas mettre dans la boucle while :

# Tout d'abord, on te donne la condition d'arrêt de la boucle en partant de l'hypothèse que tu as stocké le HumanPlayer dans la variable user et les deux Player dans les variables player1 et player2.
# while user.life_points >0 && (player1.life_points > 0 || player2.life_points >0)
#   ...
# end
# La première chose qu'on va faire à chaque tour de combat, c'est afficher l'état du HumanPlayer : rajoute cela.
# Ensuite, on va proposer un menu qui doit ressembler à cela :
# Quelle action veux-tu effectuer ?

# a - chercher une meilleure arme
# s - chercher à se soigner 

# attaquer un joueur en vue :
# 0 - Josiane a 10 points de vie
# 1 - José a 10 points de vie
# Évidemment la partie "Josiane a 10 points de vie" et "José a 10 points de vie" devra se mettre à jour quand ils vont recevoir des dégâts. Tu dois donc utiliser la méthode show_state dans cette partie du menu pour afficher l'état réel de chaque Player que l'utilisateur combat.
# Une fois cela fait, on laisse l'utilisateur effectuer une saisie. Et en fonction de la saisie, on va :
# si l'utilisateur tape "a", exécuter sur son HumanPlayer la méthode qui le fait partir à la recherche d'une arme ;
# si l'utilisateur tape "s", exécuter sur son HumanPlayer la méthode qui le fait partir à la recherche d'un pack de soin ;
# si l'utilisateur tape "0", faire attaquer Josiane par son Human Player ;
# si l'utilisateur tape "1", faire attaquer José par son Human Player ;
# C'est maintenant au tour des ennemis de riposter ! Tu peux l'indiquer en affichant en console un petit puts "Les autres joueurs t'attaquent !"
# On va faire que les 2 Player attaquent le HumanPlayer. Mais au lieu d'écrire 2 lignes quasiment identiques en mode player1.attacks(user) et player2.attacks(user), je veux que tu utilises l'array enemies contenant les 2 objets Player. L'idée est de faire une boucle each sur cet array pour ensuite exécuter la méthode attacks sur chaque objet. Pourquoi ? Tout simplement car on anticipe là le fait qu'il y aura bientôt 10 ou 20 ou 30 Player : on va pas se taper 10 ou 20 ou 30 lignes de playerX.attacks(user) !
# Ha oui, un petit dernier truc : il ne faut pas qu'un Player puisse attaquer s'il est mort… Donc rajoute un petit if dans ta boucle each.
# Super ! Tu es arrivé au bout de la version 2.0 de ton Fornite-like ! Lance plusieurs combats, fais plein de tests et compare les résultats avec tes fellow moussaillons. N'hésite pas à mettre des petits gets.chomp ici et là qui auront pour seul objectif de faire une petite pause dans l'affichage du texte du jeu sur le terminal. Ça aidera à la lecture et à suivre ce qu'il se passe.